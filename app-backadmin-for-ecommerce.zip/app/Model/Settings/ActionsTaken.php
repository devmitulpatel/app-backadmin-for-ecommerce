<?php

namespace App\Model\Settings;

use Illuminate\Database\Eloquent\Model;

class ActionsTaken extends Model
{
    //
}
