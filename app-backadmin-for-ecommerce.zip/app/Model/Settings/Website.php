<?php

namespace App\Model\Settings;

use Illuminate\Database\Eloquent\Model;

class Website extends Model
{
  protected $table='settings_websites';
}
