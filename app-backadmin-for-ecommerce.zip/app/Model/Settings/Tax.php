<?php

namespace App\Model\Settings;

use Illuminate\Database\Eloquent\Model;

class Tax extends Model
{
    //
}
