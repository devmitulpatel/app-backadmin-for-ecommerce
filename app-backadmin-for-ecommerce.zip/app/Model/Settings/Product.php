<?php

namespace App\Model\Settings;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{


    protected $table= 'product_settings';


}
