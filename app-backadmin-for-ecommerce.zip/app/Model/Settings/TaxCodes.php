<?php

namespace App\Model\Settings;

use Illuminate\Database\Eloquent\Model;

class TaxCodes extends Model
{
    //
}
