<?php

namespace App\Model\Settings\Product;

use Illuminate\Database\Eloquent\Model;

class Extra_Field extends Model
{
    //
}
