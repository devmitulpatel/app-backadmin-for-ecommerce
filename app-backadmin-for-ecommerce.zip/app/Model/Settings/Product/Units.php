<?php

namespace App\Model\Settings\Product;

use Illuminate\Database\Eloquent\Model;

class Units extends Model
{
    //


    protected static function boot(){
        parent::boot();


    }

}
