<?php

namespace App\Model\Product;

use Illuminate\Database\Eloquent\Model;

class ProductImages extends Model
{
    //
}
