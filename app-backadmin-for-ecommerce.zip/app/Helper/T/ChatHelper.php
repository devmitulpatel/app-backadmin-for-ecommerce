<?php


namespace App\Helper\T;


trait ChatHelper
{


    public function tD($d=[],$ed=[]){
        return throwData($d,$ed);

    }



}
